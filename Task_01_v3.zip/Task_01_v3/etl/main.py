import yaml
import argparse
import logging
from storages import select_storage
from transformers import select_transformer
from extractors import select_extractor
from utils.logger import setup_logging
import os

def load_config(file_name):
    with open(file_name, 'r') as file:
        return yaml.safe_load(file)
    
def initialize_configurations(config, platform):
    app_name = config['appName']
    extractor_config = config['extract']
    transformer_config = config['transformer']
    storage_config = config['storage']

    storage = select_storage(
                name=storage_config['name']
                )(
                    app_name=app_name, 
                    config=storage_config
                )
    transformer = select_transformer(
                    platform=platform, 
                    name=transformer_config['name']
                    )(
                        app_name=app_name, 
                        storage=storage, 
                        config=storage_config
                    )
    extractor = select_extractor(
                    name=extractor_config['name']
                    )(
                        app_name=app_name, 
                        config=extractor_config, 
                        transformer=transformer
                    )

    extractor.fetch()

def main():
    # Use argparse to handle CLI arguments
    parser = argparse.ArgumentParser(description='Run ETL pipeline with dynamic platform configuration...')
    parser.add_argument('--path', default=os.getcwd() , help='Configuration file path')
    parser.add_argument('--config', required=True, help='Configuration YAML file name')
    parser.add_argument('--platform', default='pandas', choices=['pandas', 'polars'], help='Platform to use for transformation. (Pandas or Polars)')

    args = parser.parse_args()

    # Load the weather config
    config = load_config(file_name=args.config)

    setup_logging(config['meta']['logging_level'])
    initialize_configurations(config=config, platform=args.platform)

if __name__ == "__main__":
    main()