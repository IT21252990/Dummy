from transformers.pandas.weather_transformer_pandas import WeatherTransformer
from transformers.polars.weather_transformer_polars import WeatherTransformerPolars
from transformers.no_opp_transformer import NoOppTransformer


def select_transformer(platform, name):
    transformers: dict = {
        'polars': {
            'NO_OPP_TRANSFORMER': NoOppTransformer,
            'WEATHER_TRANSFORMER': WeatherTransformerPolars
        },
        'pandas': {
            'NO_OPP_TRANSFORMER': NoOppTransformer,
            'WEATHER_TRANSFORMER': WeatherTransformer
        }
    }

    return transformers.get(platform, {}).get(name, None)