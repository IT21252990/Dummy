from datetime import datetime
import logging
import pyarrow as pa
import pandas as pd
from typing import Union
from transformers.base_transformer import BaseTransformer

class Json2ArrowTransformer(BaseTransformer):
    NAME = 'JSON_TO_ARROW'

    def __init__(self, app_name: str, storage, config: dict) -> None:
        super().__init__(app_name , storage, config) 
        logging.info("Initialized JSON_TO_ARROW.")
    
    def _transform(self, data) :
        logging.info("Transforming json data to arrow table.")

        arrow_table = data
        return arrow_table

    # def _transform(self, data: dict) :
    #     logging.info("Transforming json data to arrow table.")

    #     # Convert arrow table into pandas
    #     # df = pd.DataFrame(data)
    #     arrow_table = pa.Table.from_arrays(data)
    #     return arrow_table


class WeatherTransformer(BaseTransformer):
    NAME = 'WEATHER_TRANSFORMER'

    def __init__(self, app_name: str, storage, config: dict) -> None:
        super().__init__(app_name , storage, config) 
        logging.info("Initialized Pandas DataTransformer.")

    def _transform(self, data: pa.Table) :
        logging.info("Transforming data using Pandas...")

        # Convert arrow table into pandas
        df = data.to_pandas()

        rows = []

        for _, entry in df.iterrows():

            #Extract the needed fields form the raw data
            city = entry['name']
            country = entry['sys']['country']
            datetime_now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            temperature = entry['main']['temp']
            humidity = entry['main']['humidity']
            weather = entry['weather'][0]['description']
            pressure = entry['main']['pressure']
            wind_speed = entry['wind']['speed']

            # Define the metrics and their values
            metrics = {
                'temperature (Celsius)' : temperature,
                'humidity (%)' : humidity,
                'weather' : weather,
                'pressure (hPa)' : pressure,
                'wind speed (meter/sec)' : wind_speed
            }

            # Reshape data
            for metric , value in metrics.items():
                rows.append({
                    'DateTime' : datetime_now,
                    'CountryCode' : country,
                    'City' : city,
                    'Metric' : metric,
                    'Value' : value
                })

        # Create a pandas DataFrame
        df_transformed = pd.DataFrame(rows)

        df_transformed['Value'] = df_transformed['Value'].astype(str)

        arrow_table = pa.Table.from_pandas(df_transformed)

        logging.info("Data transformation using Pandas Completed.")
        return arrow_table
