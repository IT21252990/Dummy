import logging
from transformers.base_transformer import BaseTransformer
from transformers.pandas.weather_transformer_pandas import WeatherTransformer, Json2ArrowTransformer
from transformers.polars.weather_transformer_polars import WeatherTransformerPolars
from transformers.no_opp_transformer import NoOppTransformer

class ChainTransformer(BaseTransformer):
    NAME = 'TRANSFORMER_CHAIN'

    def __init__(self, app_name: str, storage, config: dict) -> None:
        super().__init__(app_name , storage, config)
        self._platform = self.PLATFORM

        logging.info("Initialized Chain Transformer.")

    def _transform(self, data):
        
        transformers = self._config.get('transformers', [])

        if bool(transformers):

            for t_config in transformers:

                transformer = TransformerSelector.select_transformer(
                    platform=self._platform, 
                    name=t_config['name']
                )(app_name=self._app_name, storage=self._storage, config=t_config)

                data = transformer.transform(data)
            
        return data
    
class TransformerSelector(object):
    @classmethod
    def select_transformer(cls, platform, name):
        transformers: dict = {
            'polars': {
                'NO_OPP_TRANSFORMER': NoOppTransformer,
                'TRANSFORMER_CHAIN': ChainTransformer,
                'WEATHER_TRANSFORMER': WeatherTransformerPolars
            },
            'pandas': {
                'NO_OPP_TRANSFORMER': NoOppTransformer,
                'TRANSFORMER_CHAIN': ChainTransformer,
                'WEATHER_TRANSFORMER': WeatherTransformer,
                'JSON_TO_ARROW': Json2ArrowTransformer
            }
        }

        transformer = transformers.get(platform, {}).get(name, None)

        if name == 'TRANSFORMER_CHAIN':
            transformer.PLATFORM = platform

        return transformer

