from datetime import datetime
import logging

import polars as pl

from transformers.base_transformer import BaseTransformer

class WeatherTransformerPolars(BaseTransformer):
    NAME = 'WEATHER_TRANSFORMER_POLARS'

    def __init__(self, app_name: str, storage, config: dict) -> None:
        super().__init__(app_name , storage, config) 
        logging.info("Initialized Polars DataTransformer.")
        self._file_name = config.get('input_file_name')
        self._file_type = config.get('input_file_type')

    def _transform(self, data):
        logging.info("Transforming data using Polars...")

        rows = []

        for entry in data:

            #Extract the needed fields form the raw data
            city = entry['name']
            country = entry['sys']['country']
            datetime_now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            temperature = entry['main']['temp']
            humidity = entry['main']['humidity']
            weather = entry['weather'][0]['description']
            pressure = entry['main']['pressure']
            wind_speed = entry['wind']['speed']

            # Define the metrics and their values
            metrics = {
                'temperature (Celsius)' : temperature,
                'humidity (%)' : humidity,
                'weather' : weather,
                'pressure (hPa)' : pressure,
                'wind speed (meter/sec)' : wind_speed
            }

            # Reshape data
            for metric , value in metrics.items():
                rows.append({
                    'DateTime' : datetime_now,
                    'CountryCode' : country,
                    'City' : city,
                    'Metric' : metric,
                    'Value' : value
                })

        # Create a polars DataFrame
        df = pl.DataFrame(rows)
        
        # Convert polars DtaFrame into pandas DataFrame
        pandas_df = df.to_pandas()

        logging.info("Data transformation using Polars Completed.")
        return pandas_df
