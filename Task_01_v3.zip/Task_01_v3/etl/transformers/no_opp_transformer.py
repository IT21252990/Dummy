import logging

from transformers.base_transformer import BaseTransformer

class NoOppTransformer(BaseTransformer):
    NAME = 'NO_OPP_TRANSFORMER'

    def __init__(self, app_name: str, storage, config: dict) -> None:
        super().__init__(app_name, storage, config)
        self._data = None

    def _transform(self, data):
        logging.info(f'Transforming data...')
        self._data = data
        return data
