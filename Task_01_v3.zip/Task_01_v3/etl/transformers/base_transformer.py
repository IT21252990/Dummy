class BaseTransformer:
    NAME = 'BASE_TRANSFORMER'

    def __init__(self, app_name: str, storage, config: dict) -> None:
        self._app_name = app_name
        self._storage = storage
        self._config = config
        self._return_obj = config.get('return_obj', False)

    def transform(self, data):
        df = self._transform(data)

        if bool(self._return_obj):
            return df
        elif df is not None:
            self._storage.save(df)

    def _transform(self, data):
        raise NotImplementedError('Not Implemented')


    