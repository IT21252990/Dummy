import json
import os
import logging
from storages.base_storage import BaseStorage

class FileStorage(BaseStorage):
    NAME = 'FILE_STORAGE'

    def __init__(self, app_name: str, config: dict) -> None:
        super().__init__(app_name, config)
        self._directory = config.get('directory')
        self.output_file_name = config.get('output_file_name')
        self.output_file_type = config.get('output_file_type')

        #Create the directory if it doesn't exist
        output_dir = os.path.dirname(self._directory)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir , exist_ok=True)

    def _save(self,data):
        output_file = os.path.join(os.path.dirname(self._directory), f'{self.output_file_name}.{self.output_file_type}')

        logging.info(f'saving data to {output_file}')

        file_exists = os.path.isfile(output_file)

        if (self.input_file_type.lower() == 'json' and  self.output_file_type.lower() == ''):
            # save the json data
            with open(output_file, 'w') as f:
                json.dump(data, f, indent=4)
        elif (self.output_file_type.lower() == 'csv' and self.input_file_type.lower() == 'json'):
            # save the data in csv file
            data.to_csv(output_file, mode='a', index=False, header=not file_exists)
        else:
            raise ValueError('Invalid data type or file type.')
        
        logging.info(f'Data saved successfully at {output_file}')
