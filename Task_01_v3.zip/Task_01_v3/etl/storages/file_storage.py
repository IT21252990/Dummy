import json
import os
import logging
import pyarrow as pa
from pyarrow import csv
from storages.base_storage import BaseStorage

class FileStorage(BaseStorage):
    NAME = 'FILE_STORAGE'

    def __init__(self, app_name: str, config: dict) -> None:
        super().__init__(app_name, config)
        self._directory = config.get('directory')
        self.output_file_name = config.get('file_name')
        self.output_file_type = config.get('file_type')

        #Create the directory if it doesn't exist
        output_dir = os.path.dirname(self._directory)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir , exist_ok=True)


    def _save(self,data):
        # IF output file or file type not specified raise an error

        # if()

        output_file = os.path.join(os.path.dirname(self._directory), f'{self.output_file_name}.{self.output_file_type}')
        print(data)
        logging.info(f'saving data to {output_file}')

        file_exists = os.path.isfile(output_file)

        if (self.output_file_type.lower() == 'json'):
            data_dict = data.to_pylist()  # data.to_pydict --> convert to the ordered python dictionary
            # save the json data
            with open(output_file, 'w') as f:
                json.dump(data_dict, f, indent=4)
        elif (self.output_file_type.lower() == 'csv'):
            csv.write_csv(data , output_file, write_options=csv.WriteOptions(include_header=True))
        else:
            raise ValueError('Invalid data type or file type.')
        
        logging.info(f'Data saved successfully at {output_file}')
