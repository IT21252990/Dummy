import os
import psycopg2
import pyarrow as pa
import pandas as pd
from storages.base_storage import BaseStorage

class PostgresStorage(BaseStorage):
    NAME = 'POSTGRES_STORAGE'

    def __init__(self, app_name: str, config) -> None:
        super().__init__(app_name, config)
        
        # Load database connection configurations from config
        self._db_name = config['db_name']
        self._db_user = config['db_user']
        self._db_password = config['db_password']
        self._db_host = config['db_host']
        self._db_port = config['db_port']
        self._table_name = config['table_name']

        # Create the connection string
        self._connection_string = f"dbname={self._db_name} user={self._db_user} password={self._db_password} host={self._db_host} port={self._db_port}"

    def save(self, arrow_table: pa.Table):
        """Save Arrow table directly to the PostgreSQL database using psycopg2."""
        
        # Convert the Arrow Table to Pandas DataFrame
        df = arrow_table.to_pandas()

        #df.columns = [col.lower() for col in df.columns]

        # Create the INSERT INTO statement with placeholders for data
        columns = list(df.columns)
        insert_query = f"""
            INSERT INTO {self._table_name} ({', '.join(columns)}) 
            VALUES ({', '.join(['%s'] * len(columns))})
        """

        # Convert DataFrame rows to tuples
        data = [tuple(row) for row in df.itertuples(index=False, name=None)]

        # Open a connection to the PostgreSQL database
        try:
            connection = psycopg2.connect(self._connection_string)
            cursor = connection.cursor()

            # Execute batch insertions using psycopg2's executemany method
            cursor.executemany(insert_query, data)

            # Commit the transaction
            connection.commit()

            print(f"Data successfully saved to PostgreSQL table '{self._table_name}'")

        except Exception as e:
            # Handle exceptions and roll back if necessary
            if connection:
                connection.rollback()
            print(f"Error occurred while saving data: {e}")

        finally:
            # Ensure the cursor and connection are closed properly
            if cursor:
                cursor.close()
            if connection:
                connection.close()
