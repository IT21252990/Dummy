from storages.file_storage import FileStorage


def select_storage(name):
    storages: dict = {
        'FILE_STORAGE': FileStorage
    }

    return storages.get(name, None)