from storages.postgres_storage import PostgresStorage
from storages.file_storage import FileStorage


def select_storage(name):
    storages: dict = {
        'FILE_STORAGE': FileStorage,
        'POSTGRES_STORAGE': PostgresStorage
    }

    return storages.get(name, None)