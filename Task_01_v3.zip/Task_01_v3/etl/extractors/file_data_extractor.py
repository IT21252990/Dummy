import json
import logging
from extractors.base_extractor import BaseExtractor

class FileDataExtractor(BaseExtractor):
    NAME = 'FILE_DATA_EXTRACTOR'

    def __init__(self , app_name: str , config: dict , transformer) -> None:
        super().__init__(app_name, transformer, config)
        self._file_directory = config.get('directory' , '')
        self._file_name = config.get('file_name' , '')
        self._file_type = config.get('file_type' , '')

    def _fetch(self):
        logging.info('Reading Weather data from file...')

        file_path = f'{self._file_directory}{self._file_name}.{self._file_type}'

        try:
            with open(file_path, 'r') as json_file:
                data = json.load(json_file)
                logging.info(f'Successfully read data from {file_path}.')
                return data, []
        except Exception as e:
            logging.error(f'Failed to read data from {file_path}. Error: {str(e)}')
            return [], [str(e)]