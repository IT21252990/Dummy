from extractors.weather_extractor import WeatherExtractor
from extractors.file_data_extractor import FileDataExtractor


def select_extractor(name):
    extractors: dict = {
        'OPEN_WEATHER_API': WeatherExtractor,
        'FILE_DATA_EXTRACTOR': FileDataExtractor
    }

    return extractors.get(name, None)