import requests
import logging
import os
from time import sleep
from extractors.base_extractor import BaseExtractor

class WeatherExtractor(BaseExtractor):
    NAME = 'OPEN_WEATHER_API'

    def __init__(self , app_name: str , config: dict , transformer):
        super().__init__(app_name , transformer , config )
        self._request_config = config.get('request')
        self._cities =  self._request_config.get('cities' , [])
        self._units =  self._request_config.get('units' , 'metric')
        self._sleep = int( self._request_config.get('sleep' , '10')) # in seconds
        self._batch_size = int( self._request_config.get('batch_size' , '50')) # max batch size is 60 (number of API calls per minute)
        # self._api_key =  self._request_config.get('api_key' , '341d03a5a889f591095a6a9aa9a24e71')
        self._api_key =  os.getenv('OPEN_WEATHER_API_KEY')
        self._url = 'https://api.openweathermap.org/data/2.5/weather'
        logging.info(f'the api key is : {self._api_key}')

    def _prepare_request(self, cities: list, units: str, batch_size: int):
        logging.debug("Preparing requests...")
        request_data = []

        for city in cities:
            request_data.append({
                'url': self._url,
                'params': {
                    'q': city,
                    'appid': self._api_key,
                    'units': units
                }
            })

        # Create batches of requests
        request_batches = [request_data[i:i + batch_size] for i in range(0, len(request_data), batch_size)]
        return request_batches

    def _fetch(self):
        logging.info('Fetching weather data...')
        request_batches = self._prepare_request(self._cities, self._units, self._batch_size)

        results = []
        errors = []

        for batch_index, batch in enumerate(request_batches):
            logging.debug(f"Processing batch {batch_index + 1}/{len(request_batches)}...")
            for request in batch:
                logging.debug(f"Sending request for {request['params']['q']}...")
                response = requests.get(request['url'], params=request['params'])

                if response.status_code == 200:
                    logging.info(f'Weather data for {request["params"]["q"]} fetched successfully')
                    results.append(response.json())
                else:
                    logging.error(f'Failed to fetch data for {request["params"]["q"]}. Status code: {response.status_code}')
                    errors.append(request['params']['q'])

            logging.debug(f"Sleeping for {self._sleep} seconds to respect API rate limits...")
            sleep(self._sleep)  # Respect the API rate limits

        logging.info(f"Fetched {len(results)} results and encountered {len(errors)} errors.")
        return results, errors