class BaseExtractor:
    NAME = 'BASE_EXTRACTOR'

    def __init__(self, app_name: str, transformer, config: dict) -> None:#config
        self._app_name = app_name
        self._transformer = transformer
        self._config = config

    def fetch(self):
        results , errors = self._fetch()

        if(results):
            self._transformer.transform(results)

    def _fetch(self):
        raise NotImplementedError('Not Implemented')