import yaml
import logging

from extractors import select_extractor
from storages.json_storage import JsonStorage
from transformers.pandas.json_transformer import JsonTransformer
from utils.logger import setup_logging

with open('config.yaml', 'r') as file:
    config = yaml.safe_load(file)

setup_logging(config['meta']['logging_level'])

def main():
    json_storage = JsonStorage(config['storage']['raw_json'])
    json_transformer = JsonTransformer(json_storage)
    weather_extractor = select_extractor(config['extract']['name'])

    weather_extractor.fetch(config['extract']['name']['request'], json_transformer)

if __name__ == "__main__":
    main()