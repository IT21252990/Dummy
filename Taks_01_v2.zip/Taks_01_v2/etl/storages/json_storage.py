import json
import pandas as pd
import os
from storages.base_storage import BaseStorage

class JsonStorage(BaseStorage):
    def __init__(self, app_name: str, directory) -> None:
        super().__init__(app_name)
        self._directory = directory

        #Create the directory if it doesn't exist
        output_dir = os.path.dirname(self._directory)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir , exist_ok=True)

    def save(self, data, file_name, file_type):

        output_file = os.path.join(os.path.dirname(self._directory), f'{file_name}.{file_type.lowe()}')

        if file_type.lower() == 'json' and (isinstance(data, dict) or isinstance(data, list)):
            # save the json data
            with open(output_file, 'w') as f:
                json.dump(data, f, indent=4)

        else:
            raise ValueError('Invalid data type or file type. Expected "json".')