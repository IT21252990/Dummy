class BaseStorage:
    TYPE = 'BASE_STORAGE'

    def __init__(self, app_name: str) -> None:
        self._app_name = app_name

    def save(self):
        self._save()

    def _save(self):
        raise NotImplementedError('Not Implemented')

    