class BaseTransformer:
    TYPE = 'BASE_TRANSFORMER'

    def __init__(self, app_name: str, storage) -> None:
        self._app_name = app_name
        self._storage = storage

    def transform(self):
        df = self._transform()

        if(df):
            self._storage.save(df)

    def _transform(self):
        raise NotImplementedError('Not Implemented')

    