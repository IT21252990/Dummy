import logging

from transformers.pandas.base_transformer import BaseTransformer

class JsonTransformer(BaseTransformer):
    NAME = 'JSON_TRANSFORMER'

    def __init__(self, app_name: str, data) -> None:
        super().__init__(app_name)
        self._data = data

    def _transform(self, data):
        return data
