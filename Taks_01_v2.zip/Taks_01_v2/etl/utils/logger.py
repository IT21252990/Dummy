import logging
from logging.handlers import RotatingFileHandler
import os

def setup_logging(level):
    logging_level = getattr(logging, level.upper(), logging.INFO)

    if not os.path.exists('logs'):
        os.makedirs('logs')

    file_handler = RotatingFileHandler(
        'logs/etl.log', maxBytes=5*1014*1024, backupCount=3
    )

    logging.basicConfig(
        level=logging_level,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            file_handler
        ]
    )