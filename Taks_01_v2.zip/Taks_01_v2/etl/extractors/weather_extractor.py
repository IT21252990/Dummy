import requests
import logging
import os
from time import sleep
from extractors.base_extractor import BaseExtractor

class WeatherExtractor(BaseExtractor):
    NAME = 'OPEN_WEATHER_API'

    def __init__(self , app_name: str , request_config: dict):
        super().__init__(app_name)
        self._cities = request_config.get('cities' , [])
        self._units = request_config.get('units' , 'metric')
        self._sleep = request_config.get('sleep' , '10') # in seconds
        self._batch_size = request_config.get('batch_size' , '50') # max batch size is 60 (number of API calls per minute)
        self._api_key = os.getenv('OPEN_WEATHER_API_KEY')
        self._url = 'https://api.openweathermap.org/data/2.5/weather'

    def _prepare_request(self , cities: list, units: str, batch_size: int):
        request_data: list = []

        for city in cities:
            request_data.append({
                'url': self._url,
                'params': {
                    'q' : city,
                    'appid' : self._api_key,
                    'units' : units
                }
            })

        request_batches = [request_data[i:i+batch_size] for i in range(0, len(request_data), batch_size)]

        return request_batches
    
    def _fetch(self):
        logging.info(f'Fetching weather data...')
        request_batches = self._prepare_request(self._cities, self._units, self._batch_size)

        results: list = []
        errors: list = []

        for batch in request_batches:
            for request in batch:
                response = requests.get(**request)

                # Check if the request was successful
                if response.status_code == 200:
                    logging.info(f'Weather data for {response.request.city} fetched successfully')
                    results.append(response.json())
                else:
                    logging.info(f'Failed to fetch data for {response.request.city}. Status code: {response.status_code}')
                    errors.append(response.request.url)
            
            sleep(self._sleep)

        return(results, errors)
