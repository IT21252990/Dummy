from extractors.weather_extractor import WeatherExtractor


def select_extractor(name):
    extractors: dict = {
        'OPEN_WEATHER_API': WeatherExtractor
    }

    return extractors.get(name, None)