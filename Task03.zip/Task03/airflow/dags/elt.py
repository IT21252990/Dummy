from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.email import EmailOperator
from airflow.operators.python import PythonOperator
from airflow.sensors.time_sensor import TimeSensor
from airflow.utils.trigger_rule import TriggerRule
from airflow.utils.task_group import TaskGroup
from datetime import datetime, time, timedelta
import pendulum
import glob
import os
import logging

# Set local timezone
local_tz = pendulum.timezone("Asia/Colombo")

# Email configuration
EMAIL_RECIPIENTS = ['kalingajayathilaka@gmail.com']
EMAIL_SUBJECT = 'new New Weather Metrics Visualization'
EMAIL_BODY = """
Hi,

Please find attached the latest weather metrics visualization for the past hour.

Best regards,
Your ETL Pipeline
"""
OUTPUT_DIRECTORY = '/opt/airflow/etl/weather_images'

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email_on_failure': True,  # Send email on task failure
    'email_on_retry': False,
    'retries': 1,
}

def find_latest_png(**context):
    """Fetch the latest PNG file from the output directory."""
    list_of_files = glob.glob(os.path.join(OUTPUT_DIRECTORY, '*.png'))
    if list_of_files:
        latest_file = max(list_of_files, key=os.path.getctime)  # Get the most recently created file
        logging.info(f"Latest PNG file found: {latest_file}")
        context['ti'].xcom_push(key='latest_png_file', value=latest_file)  # Push the file path to XCom
    else:
        raise FileNotFoundError("No PNG files found in the output directory.")

# Define the DAG
with DAG(
    dag_id='02_etl_pipeline_with_hourly_aggregation',
    default_args=default_args,
    description='Run weather data ETL pipeline with hourly aggregation and email',
    schedule_interval='*/5 0-0 * * 1-5',  # Every 5 minutes, Mon-Fri between 6 AM to 6 PM
    start_date=datetime(2024, 1, 1, tzinfo=local_tz),
    catchup=False,
    tags=['ETL'],
) as dag:

    # Task to fetch weather data every 5 minutes
    fetch_weather_data = BashOperator(
        task_id='fetch_weather_data',
        bash_command='cd /opt/airflow/etl && python main.py --config config.yaml --platform pandas --etl_type fetch',
        email_on_failure=True,
    )

    # Group tasks that should run at the end of the hour
    with TaskGroup("hourly_tasks", tooltip="Tasks to run at the end of the hour") as hourly_tasks:

        # Sensor to wait until the end of the hour
        def next_full_hour():
            """Calculate the next full hour in local timezone."""
            now = datetime.now(local_tz)
            next_hour = (now + timedelta(hours=1)).replace(minute=0, second=0, microsecond=0)
            return next_hour.time()

        wait_until_next_hour = TimeSensor(
            task_id='wait_until_next_hour',
            target_time=next_full_hour(),  # Pass the next full hour as a `datetime.time` object
            poke_interval=60,  # Check every 60 seconds
            timeout=3600,  # Timeout after 1 hour if the condition isn't met
        )

        # Task to aggregate daily files and generate visualization at the end of the hour
        aggregate_and_visualize = BashOperator(
            task_id='aggregate_and_visualize',
            bash_command='cd /opt/airflow/etl && python main.py --config config.yaml --platform pandas --etl_type aggregate',
            email_on_failure=True,
        )

        # Task to fetch the latest PNG file
        fetch_latest_png = PythonOperator(
            task_id='fetch_latest_png',
            python_callable=find_latest_png,
            trigger_rule=TriggerRule.ALL_SUCCESS,  # Run only if all upstream tasks succeed
            email_on_failure=True,
        )

        # Task to send email with the visualization
        send_email = EmailOperator(
            task_id='send_email',
            to=EMAIL_RECIPIENTS,
            subject=EMAIL_SUBJECT,
            html_content=EMAIL_BODY,
            files=["{{ ti.xcom_pull(task_ids='hourly_tasks.fetch_latest_png', key='latest_png_file') }}"],  # Pull file path from XCom
            trigger_rule=TriggerRule.ALL_SUCCESS,  # Run only if all upstream tasks succeed
            email_on_failure=True,
        )

        # Define dependencies within the hourly tasks
        wait_until_next_hour >> aggregate_and_visualize >> fetch_latest_png >> send_email

    # Define dependencies between task groups
    fetch_weather_data >> hourly_tasks

