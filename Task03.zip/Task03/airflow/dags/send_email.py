from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.operators.bash import BashOperator
from airflow.operators.email import EmailOperator
from airflow.operators.python import PythonOperator
from datetime import datetime, timedelta
import pendulum
import os
import logging
from minio import Minio

# Set local timezone
local_tz = pendulum.timezone("Asia/Colombo")

# Format today's date
today_date = datetime.now().strftime('%A, %B %d, %Y')

# Email configuration
EMAIL_RECIPIENTS = ['kalingajayathilaka@gmail.com']
EMAIL_SUBJECT = f"Daily Weather Metrics Report - {today_date}"
# EMAIL_BODY = """
# Dear Recipient,

# Attached, you will find the latest daily weather metrics visualization report. This report provides key insights and trends observed in the weather data for the day.

# Should you have any questions or require further details, please feel free to reach out.

# Best regards,  
# Weather Analytics Team  
# """
EMAIL_BODY = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weather Metrics Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #001f3f; /* Navy blue background */
            color: #ffffff; /* White text */
            margin: 0;
            padding: 20px;
        }
        .container {
            width: 80%;
            max-width: 600px;
            margin: 0 auto;
            background-color: ##f5f5f5;
            color: #001f3f; /* Navy blue text */
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.9);
            padding: 20px;
        }
        h1 {
            color: #004080;
            align-self: center;
            font-size: 24px;
            margin-bottom: 10px;
        }
        p {
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Weather Metrics Report</h1>

        <p>Dear Recipient,</p>

        <p>Attached, you will find the latest daily weather metrics visualization report. This report provides key insights and trends observed in the weather data for the day.</p>

        <p>Best regards,<br>Weather Analytics Team</p>
    </div>
</body>
</html>
"""
MINIO_ENDPOINT = 'minio:9000'
MINIO_ACCESS_KEY = 'minioadmin'
MINIO_SECRET_KEY = 'minioadmin'
MINIO_SECURE = False
OUTPUT_DIRECTORY = 'daily_weather_images/'  # MinIO file directory

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

def find_latest_png(**context):
    """Fetch the latest PNG file from the MinIO directory and download it locally."""
    minio_client = Minio(
        endpoint=MINIO_ENDPOINT,
        access_key=MINIO_ACCESS_KEY,
        secret_key=MINIO_SECRET_KEY,
        secure=MINIO_SECURE
    )

    # List objects in the MinIO bucket
    objects = minio_client.list_objects('openweatherdb', prefix=OUTPUT_DIRECTORY, recursive=True)

    # Filter for PNG files
    list_of_files = [
        obj.object_name for obj in objects if obj.object_name.endswith('.png')
    ]

    if list_of_files:
        latest_file = max(list_of_files, key=lambda x: minio_client.stat_object('openweatherdb', x).last_modified)
        logging.info(f"Latest PNG file found: {latest_file}")

        # Download the file locally
        local_file_path = f"/tmp/{os.path.basename(latest_file)}"
        minio_client.fget_object('openweatherdb', latest_file, local_file_path)

        # Push local file path to XCom
        context['ti'].xcom_push(key='latest_png_file', value=local_file_path)
    else:
        raise FileNotFoundError("No PNG files found in the MinIO directory.")

with DAG(
    dag_id='generate_visualization_and_email',
    default_args=default_args,
    description='Generate weather visualization and email results daily',
    schedule_interval='0 18 * * 1-5',  # At 6 PM, Monday to Friday
    start_date=datetime(2024, 1, 1, tzinfo=local_tz),
    catchup=False,
    tags=['weather', 'visualization', 'email'],
) as dag:

    start = EmptyOperator(task_id='start')

    aggregate_and_visualize = BashOperator(
        task_id='aggregate_and_visualize',
        bash_command='cd /opt/airflow/etl && python main.py --config minio_config.yaml --platform pandas --etl_type aggregate',
        email_on_failure=True,
    )

    fetch_latest_png = PythonOperator(
        task_id='fetch_latest_png',
        python_callable=find_latest_png,
        email_on_failure=True,
    )

    send_email = EmailOperator(
        task_id='send_email',
        to=EMAIL_RECIPIENTS,
        subject=EMAIL_SUBJECT,
        html_content=EMAIL_BODY,
        files=["{{ ti.xcom_pull(task_ids='fetch_latest_png', key='latest_png_file') }}"],  # Pull file path from XCom
        email_on_failure=True,
    )

    end = EmptyOperator(task_id='end')

    # Define task flow
    start >> aggregate_and_visualize >> fetch_latest_png >> send_email >> end
