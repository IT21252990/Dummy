from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.operators.bash import BashOperator
from datetime import datetime, timedelta
import pendulum

# Set local timezone
local_tz = pendulum.timezone("Asia/Colombo")

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    dag_id='fetch_weather_data',
    default_args=default_args,
    description='Fetch weather data and store in CSV every 15 minutes',
    schedule_interval='*/15 6-18 * * 1-5',  # Every 15 minutes, 6 AM to 6 PM, Monday to Friday
    start_date=datetime(2024, 1, 1, tzinfo=local_tz),
    catchup=False,
    tags=['weather', 'fetch'],
) as dag:

    start = EmptyOperator(task_id='start')

    fetch_weather_data = BashOperator(
        task_id='fetch_weather_data',
        bash_command='cd /opt/airflow/etl && python main.py --config minio_config.yaml --platform pandas --etl_type fetch',
        email_on_failure=True,
    )

    end = EmptyOperator(task_id='end')

    # Define task flow
    start >> fetch_weather_data >> end
