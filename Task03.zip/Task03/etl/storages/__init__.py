from storages.minio_weather_image_storage import MinioWeatherImageStorage
from storages.minio_storage import MinioStorage
from storages.weather_png_loader import WeatherPNGLoader
from storages.file_storage import FileStorage


def select_storage(name):
    storages: dict = {
        'FILE_STORAGE': FileStorage,
        'WEATHER_PNG_LOADER': WeatherPNGLoader,
        'MINIO_STORAGE': MinioStorage,
        'MINIO_WEATHER_IMAGE_STORAGE' : MinioWeatherImageStorage,
    }

    return storages.get(name, None)