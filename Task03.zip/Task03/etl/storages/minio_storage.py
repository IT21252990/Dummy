from storages.base_storage import BaseStorage
from minio import Minio
from minio.error import S3Error
from datetime import datetime
import logging
import pandas as pd
import pyarrow as pa
from pyarrow import csv
import json
import io
from pytz import timezone
import pytz

class MinioStorage(BaseStorage):
    NAME = 'MINIO_STORAGE'

    def __init__(self, app_name: str, config: dict) -> None:
        super().__init__(app_name, config)
        
        # Extract MinIO configurations
        minio_config = config.get('MINIO_CONFIG', {})
        self._minio_client = Minio(
            endpoint=minio_config.get('endpoint', 'localhost:9001'),
            # endpoint=minio_config.get('endpoint', 'minio:9001'),
            access_key=minio_config.get('access_key', 'minioadmin'),
            secret_key=minio_config.get('secret_key', 'minioadmin'),
            secure=minio_config.get('secure', False)
        )
        self.bucket_name = minio_config.get('bucket_name', 'Open_weather_db')
        
        # Extract file storage configurations
        self.file_directory = config.get('directory', 'weather_data/')
        self.file_name = config.get('file_name', 'open_weather_data')
        self.file_type = config.get('file_type', 'csv')
        
        # Ensure bucket exists
        self._ensure_bucket_exists()

    def _ensure_bucket_exists(self):
        """Ensures the specified bucket exists in MinIO."""
        try:
            if not self._minio_client.bucket_exists(self.bucket_name):
                self._minio_client.make_bucket(self.bucket_name)
                logging.info(f"Created bucket: {self.bucket_name}")
            else:
                logging.info(f"Bucket {self.bucket_name} already exists.")
        except S3Error as e:
            logging.error(f"Error checking/creating bucket: {str(e)}")
            raise

    def _save(self, data: pa.Table):
        """Saves data to MinIO in the specified format."""
        # Generate file name with timestamp
        local_tz = timezone("Asia/Kolkata")
        datetime_now = datetime.now(pytz.utc).astimezone(local_tz).strftime('%Y_%m_%d_%H_%M_%S_%f')
        object_name = f"{self.file_directory}{self.file_name}_{datetime_now}.{self.file_type}"
        
        # Convert data to the appropriate format
        if self.file_type.lower() == 'json':
            file_data = json.dumps(data.to_pylist(), indent=4)
            file_bytes = io.BytesIO(file_data.encode('utf-8'))
        elif self.file_type.lower() == 'csv':
            output = io.BytesIO()
            csv.write_csv(data, output)
            file_bytes = io.BytesIO(output.getvalue())
        else:
            raise ValueError('Unsupported file type specified.')
        
        # Upload file to MinIO
        try:
            self._minio_client.put_object(
                bucket_name=self.bucket_name,
                object_name=object_name,
                data=file_bytes,
                length=file_bytes.getbuffer().nbytes,
                content_type='application/octet-stream'
            )
            logging.info(f"File {object_name} successfully uploaded to bucket {self.bucket_name}.")
        except S3Error as e:
            logging.error(f"Failed to upload file to MinIO: {str(e)}")
            raise
