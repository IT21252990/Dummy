class BaseStorage:
    NAME = 'BASE_STORAGE'

    def __init__(self, app_name: str, config: dict) -> None:
        self._app_name = app_name
        self._config = config

    def save(self, data):
        self._save(data)

    def _save(self,data):
        raise NotImplementedError('Not Implemented')

    