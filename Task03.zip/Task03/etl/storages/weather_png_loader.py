import logging
import matplotlib.pyplot as plt
import os
import pandas as pd
import pyarrow as pa
from datetime import datetime
import pytz
from pytz import timezone
from storages.base_storage import BaseStorage


class WeatherPNGLoader(BaseStorage):
    NAME = 'WEATHER_PNG_LOADER'

    def __init__(self, app_name: str, config: dict):
        super().__init__(app_name, config)
        self._output_directory = config.get('directory')
        if not os.path.exists(self._output_directory):
            os.makedirs(self._output_directory)

    def _save(self, data: pa.Table):
        logging.info("Generating PNG visualization for temperature variations (6 AM to 6 PM).")

        # Convert PyArrow Table to pandas DataFrame
        df = data.to_pandas()

        # Filter data for temperature and the time range
        temperature_data = df[df['Metric'] == 'temperature (Celsius)']

        # Ensure 'DateTime' is in datetime format
        temperature_data.loc[:, 'DateTime'] = pd.to_datetime(temperature_data['DateTime'])

        # Filter data for the time range between 6 AM and 6 PM
        temperature_data = temperature_data[
            (temperature_data['DateTime'].dt.time >= datetime.strptime('01:00', '%H:%M').time()) &
            (temperature_data['DateTime'].dt.time <= datetime.strptime('23:00', '%H:%M').time())
        ]

        if temperature_data.empty:
            logging.warning("No temperature data available between 6 AM and 6 PM.")
            return

        # Group data by city
        cities = temperature_data['City'].unique()

        # Get the current datetime in the desired timezone
        local_tz = timezone("Asia/Kolkata")  # Replace with your local timezone if needed
        datetime_now = datetime.now(pytz.utc).astimezone(local_tz).strftime('%Y-%m-%d')

        # Generate the plot
        plt.figure(figsize=(14, 8))

        for city in cities:
            city_data = temperature_data[temperature_data['City'] == city]
            x = city_data['DateTime']
            y = city_data['Value'].astype(float)

            plt.plot(x, y, marker='o', label=f'{city}', linestyle='-', linewidth=2)

        # Customize the plot
        plt.ylabel('Temperature (Celsius)')
        plt.xlabel('Time')
        plt.title(f"Temperature Variations (1 AM - 23 PM) - {datetime_now}")
        plt.legend(title="City")
        plt.grid(visible=True, linestyle='--', linewidth=0.5)
        plt.tight_layout()

        # Format x-axis to show time only
        plt.gca().xaxis.set_major_formatter(plt.matplotlib.dates.DateFormatter('%H:%M'))
        plt.gcf().autofmt_xdate()  # Rotate x-axis labels

        # Generate file name based on datetime
        formatted_datetime = datetime.now(pytz.utc).astimezone(local_tz).strftime('%Y_%m_%d')
        output_file_name = f"temperature_variation_{formatted_datetime}.png"
        output_path = os.path.join(self._output_directory, output_file_name)

        # Save the plot
        plt.savefig(output_path)
        plt.close()

        logging.info(f"Visualization saved: {output_path}")
