from datetime import datetime
import json
import os
import logging
import pandas as pd
import pyarrow as pa
from pyarrow import csv
from storages.base_storage import BaseStorage
from pytz import timezone
import pytz  # Ensure you have this library installed

class FileStorage(BaseStorage):
    NAME = 'FILE_STORAGE'

    def __init__(self, app_name: str, config: dict) -> None:
        super().__init__(app_name, config)
        self._directory = config.get('directory')
        self.output_file_name = config.get('file_name')
        self.output_file_type = config.get('file_type')

        # Create the directory if it doesn't exist
        output_dir = os.path.dirname(self._directory)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir, exist_ok=True)

    def _save(self, data):
        # Get the current local time in your desired time zone
        local_tz = timezone("Asia/Kolkata")  # Replace with your local time zone
        datetime_now = datetime.now(pytz.utc).astimezone(local_tz).strftime('%Y_%m_%d_%H_%M_%S_%f')

        output_file = os.path.join(
            os.path.dirname(self._directory),
            f'{self.output_file_name}_{datetime_now}.{self.output_file_type}'
        )
        logging.info(f'saving data to {output_file}')

        file_exists = os.path.isfile(output_file)

        if self.output_file_type.lower() == 'json':
            data_dict = data.to_pylist()  # data.to_pydict --> convert to the ordered Python dictionary
            # Save the JSON data
            with open(output_file, 'w') as f:
                json.dump(data_dict, f, indent=4)
        elif self.output_file_type.lower() == 'csv':
            write_options = csv.WriteOptions(include_header=not file_exists)

            with open(output_file, 'ab' if file_exists else 'wb') as f:
                csv.write_csv(data, f, write_options=write_options)
        else:
            raise ValueError('Invalid data type or file type.')

        logging.info(f'Data saved successfully at {output_file}')
