import io
import logging
import matplotlib.pyplot as plt
import os
import pandas as pd
import pyarrow as pa
from datetime import datetime
import pytz
from pytz import timezone
from minio import Minio
from minio.error import S3Error
from storages.base_storage import BaseStorage

class MinioWeatherImageStorage(BaseStorage):    
    NAME = 'MINIO_WEATHER_IMAGE_STORAGE'

    def __init__(self, app_name: str, config: dict):
        super().__init__(app_name, config)

        # Extract MinIO configurations
        minio_config = config.get('MINIO_CONFIG', {})
        self._minio_client = Minio(
            endpoint=minio_config.get('endpoint', 'localhost:9001'),
            # endpoint=minio_config.get('endpoint', 'minio:9001'),
            access_key=minio_config.get('access_key', 'minioadmin'),
            secret_key=minio_config.get('secret_key', 'minioadmin'),
            secure=minio_config.get('secure', False)
        )
        self._minio_bucket = minio_config.get('bucket_name', 'openweatherdb')
        self._minio_output_directory = minio_config.get('directory', 'daily_weather_images')

    def _save(self, data: pa.Table):
        logging.info("Generating PNG visualization for temperature variations (6 AM to 6 PM).")

        # Convert PyArrow Table to pandas DataFrame
        df = data.to_pandas()

        # Filter data for temperature and the time range
        temperature_data = df[df['Metric'] == 'temperature (Celsius)']

        # Ensure 'DateTime' is in datetime format
        temperature_data.loc[:, 'DateTime'] = pd.to_datetime(temperature_data['DateTime'])

        # Filter data for the time range between 6 AM and 6 PM
        temperature_data = temperature_data[
            (temperature_data['DateTime'].dt.time >= datetime.strptime('06:00', '%H:%M').time()) &
            (temperature_data['DateTime'].dt.time <= datetime.strptime('18:00', '%H:%M').time())
        ]

        if temperature_data.empty:
            logging.warning("No temperature data available between 6 AM and 6 PM.")
            return

        # Group data by city
        cities = temperature_data['City'].unique()

        # Get the current datetime in the desired timezone
        local_tz = timezone("Asia/Kolkata")  # Replace with your local timezone if needed
        datetime_now = datetime.now(pytz.utc).astimezone(local_tz).strftime('%Y-%m-%d')

        # Generate the plot
        plt.figure(figsize=(14, 8))

        for city in cities:
            city_data = temperature_data[temperature_data['City'] == city]
            x = city_data['DateTime']
            y = city_data['Value'].astype(float)

            plt.plot(x, y, marker='o', label=f'{city}', linestyle='-', linewidth=2)

        # Customize the plot
        plt.ylabel('Temperature (Celsius)')
        plt.xlabel('Time')
        plt.title(f"Temperature Variations (6 AM - 6 PM) - {datetime_now}")
        plt.legend(title="City")
        plt.grid(visible=True, linestyle='--', linewidth=0.5)
        plt.tight_layout()

        # Format x-axis to show time only
        plt.gca().xaxis.set_major_formatter(plt.matplotlib.dates.DateFormatter('%H:%M'))
        plt.gcf().autofmt_xdate()  # Rotate x-axis labels

        # Generate file name based on datetime
        formatted_datetime = datetime.now(pytz.utc).astimezone(local_tz).strftime('%Y_%m_%d')
        output_file_name = f"temperature_variation_{formatted_datetime}.png"

        # Save the plot to MinIO
        try:
            img_data = io.BytesIO()
            plt.savefig(img_data, format='png')
            img_data.seek(0)  # Reset the file pointer to the start
            self._minio_client.put_object(
                self._minio_bucket,
                f"{self._minio_output_directory}/{output_file_name}",
                img_data,
                length=img_data.getbuffer().nbytes
            )
            logging.info(f"Visualization uploaded to MinIO: {self._minio_output_directory}/{output_file_name}")
        except S3Error as e:
            logging.error(f"Failed to upload visualization to MinIO: {str(e)}")
