import io
import os
import pyarrow as pa
import pyarrow.csv as pv
import logging
from minio import Minio
from minio.error import S3Error
from extractors.base_extractor import BaseExtractor
from datetime import datetime

class MinioSingleFileExtractor(BaseExtractor):
    NAME = 'MINIO_SINGLE_FILE_EXTRACTOR'

    def __init__(self, app_name: str, config: dict, transformer):
        super().__init__(app_name, transformer, config)
        # Extract MinIO configurations
        minio_config = config.get('MINIO_CONFIG', {})
        self._minio_client = Minio(
            endpoint=minio_config.get('endpoint', 'localhost:9000'),
            access_key=minio_config.get('access_key', 'minioadmin'),
            secret_key=minio_config.get('secret_key', 'minioadmin'),
            secure=minio_config.get('secure', False)
        )
        self._bucket_name = minio_config.get('bucket_name', 'openweatherdb')
        self._directory = config.get('directory', '')  # Directory in MinIO
        self._file_name_include = config.get('filters')['include']
        self._file_type = config.get('filters')['suffix']

    def _fetch(self):
        logging.info(f"Reading the latest {self._file_type} file from {self._directory} in MinIO bucket {self._bucket_name}")

        arrow_table = None

        try:
            # List objects in the MinIO bucket
            objects = self._minio_client.list_objects(self._bucket_name, prefix=self._directory, recursive=True)

            # Filter for files matching the filename pattern
            matching_files = [
                obj.object_name for obj in objects 
                if self._file_name_include in obj.object_name and obj.object_name.endswith(self._file_type)
            ]

            if not matching_files:
                raise FileNotFoundError(f"No {self._file_type} files found in the directory {self._directory}.")

            # Get the latest file based on modification time
            latest_file = max(
                matching_files, 
                key=lambda x: self._minio_client.stat_object(self._bucket_name, x).last_modified
            )
            logging.info(f"Latest {self._file_type} file found: {latest_file}")

            # Fetch the file data
            file_data = self._minio_client.get_object(self._bucket_name, latest_file)

            if self._file_type == '.json':
                import pandas as pd
                # Read JSON data into a DataFrame
                df = pd.read_json(file_data)
                df['DateTime'] = df['DateTime'].astype(str)
                arrow_table = pa.Table.from_pandas(df)

            elif self._file_type == '.csv':
                # Read CSV data using PyArrow
                arrow_table = pv.read_csv(io.BytesIO(file_data.read()))

            else:
                raise ValueError(f"Unsupported file type: {self._file_type}")

            logging.info(f"{self._file_type.upper()} file {latest_file} loaded successfully.")
            return arrow_table, []
        except S3Error as e:
            logging.error(f"Failed to list objects in bucket or get file: {str(e)}")
            return None, [f"Failed to list objects in bucket or get file: {str(e)}"]
        except Exception as e:
            logging.error(f"Failed to read {self._file_type} file: {e}")
            return None, [str(e)]
