from extractors.minio_file_list_extractor import MinioFileListExtractor
from extractors.minio_single_file_extractor import MinioSingleFileExtractor
from extractors.file_list_extractor import FileListExtractor
from extractors.weather_extractor import WeatherExtractor
from extractors.file_data_extractor import FileDataExtractor
from extractors.file_extractor import WeatherCSVExtractor


def select_extractor(name):
    extractors: dict = {
        'OPEN_WEATHER_API': WeatherExtractor,
        'FILE_DATA_EXTRACTOR': FileDataExtractor,
        'WEATHER_CSV_EXTRACTOR': WeatherCSVExtractor,
        'FILE_LIST_EXTRACTOR' : FileListExtractor,
        'MINIO_FILE_LIST_EXTRACTOR': MinioFileListExtractor,
        'MINIO_SINGLE_FILE_EXTRACTOR' : MinioSingleFileExtractor,
    }

    return extractors.get(name, None)