import logging
import pandas as pd
import pyarrow as pa
import pyarrow.csv as pv
import io
from datetime import datetime
from minio import Minio
from minio.error import S3Error
from extractors.base_extractor import BaseExtractor

class MinioFileListExtractor(BaseExtractor):
    NAME = 'MINIO_FILE_LIST_EXTRACTOR'

    def __init__(self, app_name: str, config: dict, transformer) -> None:
        super().__init__(app_name, transformer, config)
        # Extract MinIO configurations
        minio_config = config.get('MINIO_CONFIG', {})
        self._minio_client = Minio(
            endpoint=minio_config.get('endpoint', 'localhost:9000'),
            access_key=minio_config.get('access_key', 'minioadmin'),
            secret_key=minio_config.get('secret_key', 'minioadmin'),
            secure=minio_config.get('secure', False)
        )
        self._bucket_name = minio_config.get('bucket_name', 'openweatherdb')

        self._directory = config.get('directory', '') 
        self._file_name_include = config.get('filters')['include']
        self._get_last_file = config.get('filters')['get_last']
        self._file_type = config.get('filters')['suffix']

    def _fetch(self):
        logging.info('Fetching file list from MinIO bucket...')

        # List objects in the MinIO bucket
        try:
            objects = self._minio_client.list_objects(self._bucket_name, prefix=self._directory, recursive=True)
        except S3Error as e:
            logging.error(f"Failed to list objects in bucket: {str(e)}")
            return None, [f"Failed to list objects in bucket: {str(e)}"]

        # Filter for today's files
        today_str = datetime.now().strftime('%Y_%m_%d')
        todays_files = [
            obj.object_name for obj in objects 
            if today_str in obj.object_name and obj.object_name.endswith(self._file_type)
        ]

        if not todays_files:
            logging.warning(f'No files found for today with date "{today_str}" in the filename.')
            return None, [f'No files found for today matching pattern in bucket {self._bucket_name}.']

        # Read files using PyArrow
        try:
            if self._file_type == '.json':
                df_list = []
                for file_name in todays_files:
                    try:
                        file_data = self._minio_client.get_object(self._bucket_name, file_name)
                        df_list.append(pd.read_json(file_data))
                    except Exception as e:
                        logging.error(f'Error reading JSON file: {file_name}, error: {str(e)}')
                combined_df = pd.concat(df_list, ignore_index=True)
                combined_df['DateTime'] = combined_df['DateTime'].astype(str)
                arrow_table = pa.Table.from_pandas(combined_df)

            elif self._file_type == '.csv':
                table = [pv.read_csv(io.BytesIO(self._minio_client.get_object(self._bucket_name, file_name).read())) for file_name in todays_files]
                arrow_table = pa.concat_tables(table)

            else:
                raise ValueError(f'Unsupported file type: {self._file_type}')

            logging.info(f"Successfully read data from today's files.")
            return arrow_table, []
        except Exception as e:
            logging.error(f'Failed to read data from files: {todays_files}. Error: {str(e)}')
            return None, [str(e)]
