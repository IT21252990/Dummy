import logging
import pandas as pd
import pyarrow as pa
import pyarrow.csv as pv
import glob
import os
from datetime import datetime
from extractors.base_extractor import BaseExtractor

class FileListExtractor(BaseExtractor):
    NAME = 'FILE_LIST_EXTRACTOR'

    def __init__(self, app_name: str, config: dict, transformer) -> None:
        super().__init__(app_name, transformer, config)
        self._file_directory = config.get('directory', '')
        self._file_name_include = config.get('filters')['include']
        self._get_last_file = config.get('filters')['get_last']
        self._file_type = config.get('filters')['suffix']

    def _fetch(self):
        logging.info('Fetching file list...')

        # Define file pattern based on directory and filters
        file_pattern = os.path.join(self._file_directory, f'{self._file_name_include}_*{self._file_type}')
        file_list = glob.glob(file_pattern)

        if not file_list:
            logging.error(f'No files found matching pattern: {file_pattern}')
            return None, [f'No files found matching pattern: {file_pattern}']
        
        # Get today's date in the format used in filenames
        today_str = datetime.now().strftime('%Y_%m_%d')

        # Filter files whose names contain today's date
        todays_files = [
            file for file in file_list 
            if today_str in os.path.basename(file)
        ]

        if todays_files:
            print("Today's files:")
            print("\n".join(todays_files))  # Join the list with newline separator
        else:
            print(f"No files found for today with date '{today_str}' in the filename.")

        if not todays_files:
            logging.warning(f'No files found for today with date "{today_str}" in the filename.')
            return None, [f'No files found for today matching pattern: {file_pattern}']

        try:
            if self._file_type == '.json':
                # Read and combine JSON files
                df_list = []
                for file in todays_files:
                    try:
                        df_list.append(pd.read_json(file))
                    except Exception as e:
                        logging.error(f'Error reading JSON file: {file}, error: {str(e)}')
                combined_df = pd.concat(df_list, ignore_index=True)
                combined_df['DateTime'] = combined_df['DateTime'].astype(str)
                arrow_table = pa.Table.from_pandas(combined_df)

            elif self._file_type == '.csv':
                # Read and combine CSV files
                table = [pv.read_csv(file) for file in todays_files]
                arrow_table = pa.concat_tables(table)

            else:
                raise ValueError(f'Unsupported file type: {self._file_type}')

            logging.info(f"Successfully read data from today's files.")
            return arrow_table, []
        except Exception as e:
            logging.error(f'Failed to read data from files: {todays_files}. Error: {str(e)}')
            return None, [str(e)]