import json
import logging
import pyarrow as pa
import pyarrow.json as pj
import pyarrow.csv as pv
from extractors.base_extractor import BaseExtractor

class FileDataExtractor(BaseExtractor):
    NAME = 'FILE_DATA_EXTRACTOR'

    def __init__(self , app_name: str , config: dict , transformer) -> None:
        super().__init__(app_name, transformer, config)
        self._file_directory = config.get('directory' , '')
        self._file_name = config.get('file_name' , '')
        self._file_type = config.get('file_type' , '')

    def _fetch(self):
        logging.info('Reading data from file...')

        file_path = f'{self._file_directory}{self._file_name}.{self._file_type}'
        arrow_table = None

        try:
            if self._file_type == 'json':
                arrow_table = pj.read_json(file_path)
            elif self._file_type == 'csv':
                arrow_table = pv.read_csv(file_path)
            else:
                raise ValueError(f'Unsupported file type: {self._file_type}')


            logging.info(f'Successfully read data from {file_path}.')
            return arrow_table, []
        except Exception as e:
            logging.error(f'Failed to read data from {file_path}. Error: {str(e)}')
            return None, [str(e)]