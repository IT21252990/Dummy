import os
import pyarrow.csv as pv
import logging
from extractors.base_extractor import BaseExtractor

class WeatherCSVExtractor(BaseExtractor):
    NAME = 'WEATHER_CSV_EXTRACTOR'

    def __init__(self, app_name: str, config: dict, transformer):
        super().__init__(app_name, transformer, config)
        self._input_directory = config.get('input_directory', '.')

    def _fetch(self):
        logging.info(f"Reading the latest CSV file from {self._input_directory}")

        arrow_table = None

        try:
            # Get all CSV files in the directory with their paths
            csv_files = [
                os.path.join(self._input_directory, f)
                for f in os.listdir(self._input_directory)
                if f.endswith('.csv')
            ]
            
            if not csv_files:
                raise FileNotFoundError("No CSV files found in the input directory.")
            
            # Find the most recently created or modified file
            latest_file = max(csv_files, key=os.path.getmtime)
            logging.info(f"Latest CSV file found: {latest_file}")
            
            # Load the file into a DataFrame
            arrow_table = pv.read_csv(latest_file)
            
            logging.info(f"CSV file {latest_file} loaded successfully.")
            return arrow_table, []
        except Exception as e:
            logging.error(f"Failed to read CSV: {e}")
            raise
