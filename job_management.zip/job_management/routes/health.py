from fastapi import APIRouter, status
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session
from database import get_db
import uuid
from sqlalchemy.sql import text

router = APIRouter(prefix="/api/v1", tags=["Health"])

@router.get("/health", response_model=dict)
def health_check():
    request_id = str(uuid.uuid4())
    app_status = "healthy"
    db_status = "unknown"

    try:
        db: Session = next(get_db())
        db.execute(text("SELECT 1"))
        db_status = "connected"
    except SQLAlchemyError as e:
        db_status = "disconnected"
        error_detail = str(e)
    except Exception as e:
        db_status = "error"
        error_detail = str(e)
    else:
        error_detail = None

    response = {
        "status": 200 if db_status == "connected" else 500,
        "success": db_status == "connected",
        "payload": {
            "app_status": app_status,
            "db_status": db_status
        },
        "message": "Health check successful" if db_status == "connected" else "Health check failed",
        "errors": [] if error_detail is None else [error_detail],
        "request_id": request_id
    }

    return response