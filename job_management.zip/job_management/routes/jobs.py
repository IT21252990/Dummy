from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import get_db
from crud import create_job, get_all_jobs, get_job, update_job, delete_job
from schemas import JobCreate, JobUpdate, JobResponse

router = APIRouter(prefix="/api/v1", tags=["Jobs"])

@router.post("/jobs", response_model=JobResponse)
def submit_job(job: JobCreate, db: Session = Depends(get_db)):
    return create_job(db, job)

@router.get("/jobs", response_model=List[JobResponse])
def fetch_all_jobs(db: Session = Depends(get_db)):
    return get_all_jobs(db)

@router.get("/jobs/{id}", response_model=JobResponse)
def fetch_single_job(id: str, db: Session = Depends(get_db)):
    return get_job(db, id)

@router.patch("/jobs/{id}", response_model=JobResponse)
def update_job_details(id: str, job_update: JobUpdate, db: Session = Depends(get_db)):
    return update_job(db, id, job_update)

@router.delete("/jobs/{id}")
def delete_job_entry(id: str, db: Session = Depends(get_db)):
    delete_job(db, id)
    return {"message": "Job deleted successfully"}