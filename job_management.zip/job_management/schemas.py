from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime
from enum import Enum

class JobStatus(str, Enum):
    QUEUED = "queued"
    IN_PROGRESS = "in-progress"
    SUCCESS = "success"
    FAILED = "failed"

class JobBase(BaseModel):
    name: str
    status: Optional[JobStatus] = JobStatus.QUEUED

class JobCreate(JobBase):
    pass

class JobUpdate(BaseModel):
    name: Optional[str]
    status: Optional[JobStatus]
    errors: Optional[str]

class JobResponse(JobBase):
    uuid: str
    created_at: str
    updated_at: str

    class Config:
        orm_mode = True

    @validator("created_at", "updated_at", pre=True)
    def format_datetime(cls, v: datetime):
        if isinstance(v, datetime):
            return v.isoformat()
        return v
