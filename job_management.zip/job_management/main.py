from fastapi import FastAPI
from database import Base, engine
from routes.jobs import router as jobs_router
from routes.health import router as health_router

app = FastAPI()

# Initialize database
Base.metadata.create_all(bind=engine)

app.include_router(health_router)
app.include_router(jobs_router)