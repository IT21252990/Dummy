from typing import Optional
from sqlalchemy.orm import Session
from models import Job
from schemas import JobCreate, JobUpdate
from fastapi import HTTPException

def create_job(db: Session, job: JobCreate):
    try:
        db_job = Job(**job.dict())
        db.add(db_job)
        db.commit()
        db.refresh(db_job)
        return db_job
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to create job: {str(e)}")

def get_all_jobs(db: Session):
    return db.query(Job).all()

def get_job(db: Session, job_id: str):
    job = db.query(Job).filter(Job.uuid == job_id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job

def update_job(db: Session, job_id: str, job_update: JobUpdate):
    db_job = db.query(Job).filter(Job.uuid == job_id).first()
    if not db_job:
        raise HTTPException(status_code=404, detail="Job not found")

    for key, value in job_update.dict(exclude_unset=True).items():
        setattr(db_job, key, value)
    db.commit()
    db.refresh(db_job)
    return db_job

def delete_job(db: Session, job_id: str):
    db_job = db.query(Job).filter(Job.uuid == job_id).first()
    if not db_job:
        raise HTTPException(status_code=404, detail="Job not found")

    db.delete(db_job)
    db.commit()
    return db_job